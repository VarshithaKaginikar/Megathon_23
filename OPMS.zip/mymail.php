<script>
        function we1()
        {
    var txtFirstNumberValue = document.getElementById('email').value;
    var txtSecondNumberValue = document.getElementById('name').value;
    var txtThirdNumberValue = document.getElementById('phone').value;
   
     var result = "Email:"+txtFirstNumberValue + "  Name:"+txtSecondNumberValue + "  Phone:"+ txtThirdNumberValue;
      document.getElementById('4').value = result;    
        }
        </script>          

<?php

        $message = '';

        function clean_text($string)
        {
            $string = trim($string);
            $string = stripslashes($string);
            $string = htmlspecialchars($string);
            return $string;
        }


    if (isset($_POST['btnSubmit'])) {

        $programming_languages = '';
        foreach($_POST["programming_languages"] as $row)
        {
            $programming_languages .= $row . ', ';
        }
        $programming_languages = substr($programming_languages, 0, -2);
        $path = 'upload/' . $_FILES["resume"]["name"];
        move_uploaded_file($_FILES["resume"]["tmp_name"], $path);
        $message = '
            <h3 align="center">Applicant Details</h3>
            <table border="1" width="100%" cellpadding="5" cellspacing="5">
                <tr>
                    <td width="30%">Name</td>
                    <td width="70%">'.$_POST["name"].'</td>
                </tr>
                <tr>
                    <td width="30%">Address</td>
                    <td width="70%">'.$_POST["address"].'</td>
                </tr>
                <tr>
                    <td width="30%">Email Address</td>
                    <td width="70%">'.$_POST["email"].'</td>
                </tr>
                <tr>
                    <td width="30%">Area of Interest</td>
                    <td width="70%">'.$programming_languages.'</td>
                </tr>
                <tr>
                    <td width="30%">Experience Year</td>
                    <td width="70%">'.$_POST["experience"].'</td>
                </tr>
                <tr>
                    <td width="30%">Phone Number</td>
                    <td width="70%">'.$_POST["mobile"].'</td>
                </tr>
                <tr>
                    <td width="30%">Additional Information</td>
                    <td width="70%">'.$_POST["additional_information"].'</td>
                </tr>
            </table>
        ';

                   require 'PHPMailer-master/PHPMailerAutoload.php';
                   $mail = new PHPMailer();
                   $mail ->IsSmtp();
                   $mail ->SMTPDebug = 0;
                   $mail ->SMTPAuth = true;
                   $mail ->SMTPSecure = 'ssl';
                   $mail ->Host = "cs-mum-22.webhostbox.net";
                   $mail ->Port = 465; // or 587
                   $mail ->IsHTML(true);
                   $mail->AddAttachment($path);
                   $mail ->Username = "mywebsite@trickuweb.com";
                   $mail ->Password = "9801204186Pp";
                   $mail ->SetFrom("mywebsite@trickuweb.com");
                   $mail->Subject = 'Application for JOB';				//Sets the Subject of the message
                   $mail->Body = $message;	
                   $mail->AddAddress('riceexport@trickuweb.com', 'riceexport@trickuweb.com');	

                   if($mail->Send())								//Send an Email. Return true on success or false on error
                   {
                       $message = '<div class="alert alert-success">Application Successfully Submitted</div>';
                       unlink($path);
                   }
                   else
                   {
                       $message = '<div class="alert alert-danger">There is an Error</div>';
                   }
    } 
   
?>  
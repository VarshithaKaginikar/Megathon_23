<script>
        function we1()
        {
    var txtFirstNumberValue = document.getElementById('email').value;
    var txtSecondNumberValue = document.getElementById('name').value;
    var txtThirdNumberValue = document.getElementById('phone').value;
   
     var result = "Email:"+txtFirstNumberValue + "  Name:"+txtSecondNumberValue + "  Phone:"+ txtThirdNumberValue;
      document.getElementById('4').value = result;    
        }
        </script>            
            <?php
    if (isset($_POST['btnSubmit'])) {
                    $mailto = $_POST['mail_to'];
                    $mailSub = $_POST['mail_sub'];
                    $mailMsg = $_POST['mail_msg'];
                   require 'PHPMailer-master/PHPMailerAutoload.php';
                   $mail = new PHPMailer();
                   $mail ->IsSmtp();
                   $mail ->SMTPDebug = 0;
                   $mail ->SMTPAuth = true;
                   $mail ->SMTPSecure = 'ssl';
                   $mail ->Host = "cs-mum-22.webhostbox.net";
                   $mail ->Port = 465; // or 587
                   $mail ->IsHTML(true);
                   $mail ->Username = "mywebsite@trickuweb.com";
                   $mail ->Password = "9801204186Pp";
                   $mail ->SetFrom("mywebsite@trickuweb.com");
                   $mail ->Subject = $mailSub;
                   $mail ->Body = $mailMsg;
                   $mail ->AddAddress($mailto);

                   if(!$mail->Send())
                   {
                    echo "<script>";
                        echo "alert('Message not sent! Please try again.');";
                        echo "</script>";
                   }
                   else
                   {
                        echo "<script>";
                        echo "alert('Thanks for Contacting us..! We Will Contact You Soon...');";
                        echo "</script>";
                   }
    } 
   
?>  
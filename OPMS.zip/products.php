<!DOCTYPE html>
<html lang="en">

<head>
    <title>Rice  - Get Kisan, TajMahal, Khusboo Brand Sortex Rice.</title>
    <meta name="description" content="Rice  - Get Kisan, TajMahal, Khusboo Brand Sortex Rice.">
    <?php
    include_once('header.php');
    ?>

    <!-- ##### Breadcrumb Area Start ##### -->
    <div class="breadcrumb-area">
        <!-- Top Breadcrumb Area -->
        <div class="top-breadcrumb-area bg-img bg-overlay d-flex align-items-center justify-content-center" style="background-image: url(img/bg-img/products.jpg);">
            <h2>OUR PRODUCTS</h2>
        </div>
        <!-- ##### Breadcrumb Area End ##### -->
        <!-- ##### Portfolio Area Start ##### -->
        <section class="alazea-portfolio-area section-padding-100-0">
            <div class="container">
                <div class="row">
                    <div class="col-12">
                        <!-- Section Heading -->
                        <div class="section-heading text-center">
                            <h2>WE OFFER ONLY BEST PRODUCTS</h2>
                            <p>Our products are best and hard-earned experience and reliability on high quality standards from farm to final destination, enables us to guarantee quality rice and consistent supply. Contact now to order the best quality rice from Sasaram.</p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-12">
                    <div class="alazea-portfolio-filter">
                        <div class="portfolio-filter">
                            <button class="btn active" data-filter="*">All</button>
                            <button class="btn" data-filter=".raw">Raw</button>
                            <button class="btn" data-filter=".steam20">Steam (20 kg)</button>
                            <button class="btn" data-filter=".steam25">Steam (25 kg)</button>
                            <button class="btn" data-filter=".sella20">Sella/ Boiled (20 Kg)</button>
                            <button class="btn" data-filter=".sella25">Sella/ Boiled (25 Kg)</button>
                        </div>
                    </div>
                </div>
            </div>

            <div class="row alazea-portfolio">

                <!-- Single Portfolio Area -->
                <div class="col-12 col-sm-6 col-lg-3 single_portfolio_item best-selling raw wow fadeInUp" data-wow-delay="100ms">
                    <!-- Portfolio Thumbnail -->
                    <div class="portfolio-thumbnail bg-img" style="background-image: url(img/products/classic1.jpg);"></div>
                    <!-- Portfolio Hover Text -->
                    <div class="portfolio-hover-overlay">
                        <a href="img/products/classic1.jpg" class="portfolio-img d-flex align-items-center justify-content-center" title="Portfolio 1">
                            <div class="port-hover-text">
                                <h3>Best Quality Premium Rice</h3>
                                <h5>Rice Classic Brand Rice</h5>
                            </div>
                        </a>
                    </div>
                </div>

                <!-- Single Portfolio Area -->
                <div class="col-12 col-sm-6 col-lg-3 single_portfolio_item best-selling raw wow fadeInUp" data-wow-delay="200ms">
                    <!-- Portfolio Thumbnail -->
                    <div class="portfolio-thumbnail bg-img" style="background-image: url(img/products/khusboo-25.jpg);"></div>
                    <!-- Portfolio Hover Text -->
                    <div class="portfolio-hover-overlay">
                        <a href="img/products/khusboo-25.jpg" class="portfolio-img d-flex align-items-center justify-content-center" title="Portfolio 2">
                            <div class="port-hover-text">
                                <h3>Best Quality Premium Rice</h3>
                                <h5>Rice Khusboo Brand Rice</h5>
                            </div>
                        </a>
                    </div>
                </div>

                <!-- Single Portfolio Area -->
                <div class="col-12 col-sm-6 col-lg-3 single_portfolio_item raw best-selling wow fadeInUp" data-wow-delay="300ms">
                    <!-- Portfolio Thumbnail -->
                    <div class="portfolio-thumbnail bg-img" style="background-image: url(img/products/classic2.jpg);"></div>
                    <!-- Portfolio Hover Text -->
                    <div class="portfolio-hover-overlay">
                        <a href="img/products/classic2.jpg" class="portfolio-img d-flex align-items-center justify-content-center" title="Portfolio 3">
                            <div class="port-hover-text">
                                <h3>Best Quality Premium Rice</h3>
                                <h5>Rice Classic Brand Rice</h5>
                            </div>
                        </a>
                    </div>
                </div>

                <!-- Single Portfolio Area -->
                <div class="col-12 col-sm-6 col-lg-3 single_portfolio_item garden best-selling raw wow fadeInUp" data-wow-delay="400ms">
                    <!-- Portfolio Thumbnail -->
                    <div class="portfolio-thumbnail bg-img" style="background-image: url(img/products/khusboo-o.jpg);"></div>
                    <!-- Portfolio Hover Text -->
                    <div class="portfolio-hover-overlay">
                        <a href="img/products/khusboo-o.jpg" class="portfolio-img d-flex align-items-center justify-content-center" title="Portfolio 4">
                            <div class="port-hover-text">
                                <h3>Best Quality Premium Rice</h3>
                                <h5>Rice Khusboo Brand Rice</h5>
                            </div>
                        </a>
                    </div>
                </div>
                <!-- More Products Starting -->
                <!-- Single Portfolio Area -->
                <div class="col-12 col-sm-6 col-lg-3 single_portfolio_item raw wow fadeInUp" data-wow-delay="400ms">
                    <!-- Portfolio Thumbnail -->
                    <div class="portfolio-thumbnail bg-img" style="background-image: url(img/products/kissan.jpg);"></div>
                    <!-- Portfolio Hover Text -->
                    <div class="portfolio-hover-overlay">
                        <a href="img/products/kissan.jpg" class="portfolio-img d-flex align-items-center justify-content-center" title="Portfolio 4">
                            <div class="port-hover-text">
                                <h3>Best Quality Premium Rice</h3>
                                <h5>Rice Kisaan Brand Rice</h5>
                            </div>
                        </a>
                    </div>
                </div>
                <!-- Single Portfolio Area -->
                <div class="col-12 col-sm-6 col-lg-3 single_portfolio_item raw wow fadeInUp" data-wow-delay="400ms">
                    <!-- Portfolio Thumbnail -->
                    <div class="portfolio-thumbnail bg-img" style="background-image: url(img/products/kissan-25.jpg);"></div>
                    <!-- Portfolio Hover Text -->
                    <div class="portfolio-hover-overlay">
                        <a href="img/products/kissan-25.jpg" class="portfolio-img d-flex align-items-center justify-content-center" title="Portfolio 4">
                            <div class="port-hover-text">
                                <h3>Best Quality Premium Rice</h3>
                                <h5>Rice Kisaan Brand Rice</h5>
                            </div>
                        </a>
                    </div>
                </div>
                <!-- Single Portfolio Area -->
                <div class="col-12 col-sm-6 col-lg-3 single_portfolio_item raw wow fadeInUp" data-wow-delay="400ms">
                    <!-- Portfolio Thumbnail -->
                    <div class="portfolio-thumbnail bg-img" style="background-image: url(img/products/kissan-25-2.jpg);"></div>
                    <!-- Portfolio Hover Text -->
                    <div class="portfolio-hover-overlay">
                        <a href="img/products/kissan-25-2.jpg" class="portfolio-img d-flex align-items-center justify-content-center" title="Portfolio 4">
                            <div class="port-hover-text">
                                <h3>Best Quality Premium Rice</h3>
                                <h5>Rice Kisaan Brand Rice</h5>
                            </div>
                        </a>
                    </div>
                </div>
                <!-- Single Portfolio Area -->
                <div class="col-12 col-sm-6 col-lg-3 single_portfolio_item garden raw wow fadeInUp" data-wow-delay="400ms">
                    <!-- Portfolio Thumbnail -->
                    <div class="portfolio-thumbnail bg-img" style="background-image: url(img/products/taj.jpg);"></div>
                    <!-- Portfolio Hover Text -->
                    <div class="portfolio-hover-overlay">
                        <a href="img//products/taj.jpg" class="portfolio-img d-flex align-items-center justify-content-center" title="Portfolio 4">
                            <div class="port-hover-text">
                                <h3>Best Quality Premium Rice</h3>
                                <h5>Rice Taj-Mahal Brand Rice</h5>
                            </div>
                        </a>
                    </div>
                </div>
                <!-- More Products Ending -->
                <!-- Single Portfolio Area -->
                <div class="col-12 col-sm-6 col-lg-3 single_portfolio_item design raw wow fadeInUp" data-wow-delay="100ms">
                    <!-- Portfolio Thumbnail -->
                    <div class="portfolio-thumbnail bg-img" style="background-image: url(img/products/taj-25.jpg);"></div>
                    <!-- Portfolio Hover Text -->
                    <div class="portfolio-hover-overlay">
                        <a href="img/products/taj-25.jpg" class="portfolio-img d-flex align-items-center justify-content-center" title="Portfolio 5">
                            <div class="port-hover-text">
                                <h3>Best Quality Premium Rice</h3>
                                <h5>Rice Taj-Mahal Brand Rice</h5>
                            </div>
                        </a>
                    </div>
                </div>

                <!-- Single Portfolio Area -->
                <div class="col-12 col-sm-6 col-lg-3 single_portfolio_item raw best-selling wow fadeInUp" data-wow-delay="200ms">
                    <!-- Portfolio Thumbnail -->
                    <div class="portfolio-thumbnail bg-img" style="background-image: url(img/bg-img/r3.jpg);"></div>
                    <!-- Portfolio Hover Text -->
                    <div class="portfolio-hover-overlay">
                        <a href="img/bg-img/r3.jpg" class="portfolio-img d-flex align-items-center justify-content-center" title="Portfolio 6">
                            <div class="port-hover-text">
                                <h3>Best Quality Premium Rice</h3>
                                <h5>Rice Kisaan Brand Rice</h5>
                            </div>
                        </a>
                    </div>
                </div>

                <!-- Single Portfolio Area -->
                <div class="col-12 col-lg-6 single_portfolio_item raw best-selling wow fadeInUp" data-wow-delay="300ms">
                    <!-- Portfolio Thumbnail -->
                    <div class="portfolio-thumbnail bg-img" style="background-image: url(img/bg-img/r1.jpg);"></div>
                    <!-- Portfolio Hover Text -->
                    <div class="portfolio-hover-overlay">
                        <a href="img/bg-img/r1.jpg" class="portfolio-img d-flex align-items-center justify-content-center" title="Portfolio 7">
                            <div class="port-hover-text">
                                <h3>Best Quality Premium Rice</h3>
                                <h5>Rice Khusboo Brand Rice</h5>
                            </div>
                        </a>
                    </div>
                </div>

                <?php
                include_once('sella20.php');
                include_once('sella25.php');
                include_once('steam20.php');
                include_once('steam25.php');
                ?>

            </div>
    </div>
    </section>
    <!-- ##### Portfolio Area End ##### -->
    <!-- ##### Subscribe Area Start ##### -->
    <section class="subscribe-newsletter-area mt-5" style="background-image: url(img/bg-img/subscribe.jpg);">
        <div class="container">
            <div class="row align-items-center justify-content-between">
                <div class="col-12 col-lg-9">
                    <!-- Section Heading -->
                    <div class="section-heading mb-0">
                        <h2 class="text-white">TASTE THE BEST WITH Rice INDUSTRIES</h2>
                        <p class="text-white">Our products are being exported to the many places in bihar either directly or through associates.
                            The result is guaranteed consistency at the consumer table every time. Our mission to ensure consistently longer aged rice to deliver better value to the customers.</p>
                    </div>
                </div>
                <div class="col-12 col-lg-3">
                    <div class="subscribe-form pull-right">
                        <a href="contact.php">
                            <button type="submit" class="btn alazea-btn">CONTACT NOW</button>
                        </a>
                    </div>
                </div>
            </div>
        </div>

        <!-- Subscribe Side Thumbnail -->
        <div class="subscribe-side-thumb wow fadeInUp" data-wow-delay="500ms">
            <img class="first-img" src="img/core-img/leaf.png" alt="">
        </div>
    </section>
    <!-- ##### Subscribe Area End ##### -->
    <?php
    include_once('footer.php');
    ?>